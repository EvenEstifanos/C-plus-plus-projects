// Hw1.cpp - Prints Hello World
// CMSC 140, CRN 24381, Dr. Kuijt
// Max C.

#include <iostream>
#include <string>

using namespace std;

int main()
{
    cout << "Hello, World!";
    return 0;
}